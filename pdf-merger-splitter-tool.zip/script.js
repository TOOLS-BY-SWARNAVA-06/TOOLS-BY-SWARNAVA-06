async function mergePDFs() {
  const input = document.getElementById("mergeFiles");
  if (!input.files.length) return alert("Please select PDF files.");

  const mergedPdf = await PDFLib.PDFDocument.create();

  for (let file of input.files) {
    const bytes = await file.arrayBuffer();
    const pdf = await PDFLib.PDFDocument.load(bytes);
    const pages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
    pages.forEach((page) => mergedPdf.addPage(page));
  }

  const mergedBytes = await mergedPdf.save();
  downloadBlob(mergedBytes, "merged.pdf", "application/pdf");
}

async function splitPDF() {
  const input = document.getElementById("splitFile");
  const pagesInput = document.getElementById("splitPages").value;
  if (!input.files.length || !pagesInput.trim()) {
    return alert("Select a file and enter pages (e.g. 1,3,5).");
  }

  const pageNumbers = pagesInput
    .split(",")
    .map((num) => parseInt(num.trim()) - 1)
    .filter((num) => !isNaN(num));

  const bytes = await input.files[0].arrayBuffer();
  const pdfDoc = await PDFLib.PDFDocument.load(bytes);
  const newPdf = await PDFLib.PDFDocument.create();

  const copiedPages = await newPdf.copyPages(pdfDoc, pageNumbers);
  copiedPages.forEach((page) => newPdf.addPage(page));

  const newBytes = await newPdf.save();
  downloadBlob(newBytes, "split.pdf", "application/pdf");
}

function downloadBlob(data, filename, type) {
  const blob = new Blob([data], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
